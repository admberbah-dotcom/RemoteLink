# RemoteLink safe MVP build

This build removes the unused AccessibilityService declaration and its gesture capability.
The current Android app remains a UI prototype: it does not yet implement remote screen
streaming, network pairing, or remote touch control.

Do not disable Google Play Protect or bypass an Android security warning to install it.
A successful GitHub Actions build does not mean Google has verified the developer or
certified the APK as safe. If Play Protect still reports a harmful app, stop installation
and submit the APK through Google's official Play Protect appeal / app review channels
after reviewing the source and signing identity.

For distribution beyond private testing, configure a persistent release signing key and
publish through an appropriate Google Play testing track or another trusted distribution
channel. Never commit a keystore or passwords into a public repository.
