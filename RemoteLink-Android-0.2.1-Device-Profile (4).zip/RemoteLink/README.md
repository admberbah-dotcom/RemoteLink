# RemoteLink — Android + Signaling Starter (0.2.0)

RemoteLink is a consent-based Android remote-support project for 2–5 devices. This archive contains an Android Studio starter app and a Node.js WebSocket signaling backend prototype.

## What is included

### Android app (`app/`)
- Native Kotlin Android app with controller/target role screens.
- Six-digit pairing-code UI placeholder.
- Android MediaProjection consent prompt.
- Explicit link to Android Accessibility settings.
- Accessibility service declaration, opt-in only.

### Signaling backend (`backend/`)
- WebSocket signaling endpoint (`/signal`) and health endpoint (`/health`).
- Short-lived, one-time six-digit pairing challenges (3-minute expiry).
- Host-side approval required before a session is considered paired.
- RTC offer/answer/ICE message relay after approval.
- Session expiry, disconnect handling, payload bound, and basic per-IP connection rate limiting.
- Unit checks for core protocol guardrails.

## Current status — important

This is **not a finished remote-control product and does not yet produce a working remote-control session**. The Android UI is not yet wired to the signaling backend. WebRTC media capture/transport, TURN deployment, Android foreground-service lifecycle, session persistence/device enrollment, and remote gesture dispatch are not implemented. The backend intentionally does not relay touch commands.

A production-quality unattended-access flow requires a first-time owner-approved pairing, revocable device credentials, a visible foreground session indicator, and Android's own screen-capture permission flow. Android may require renewed MediaProjection consent for each capture session depending on OS version and target SDK. No permission dialog can be bypassed.

## Run backend locally

Requires Node.js 20+.

```bash
cd backend
npm install
npm test
npm start
```

Health check: `http://localhost:8080/health`
WebSocket endpoint: `ws://localhost:8080/signal`

For public use, deploy behind a TLS reverse proxy and connect over `wss://`. Do not expose plain `ws://` on the public internet. Configure firewall, monitoring, persistent session/device storage, TURN credentials, and abuse protection before production.

## Build Android app

1. Open this folder in Android Studio.
2. Install Android SDK Platform 35 and a compatible JDK/Gradle toolchain.
3. Sync Gradle and resolve Android Gradle Plugin dependencies.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the debug APK on test devices.

This development environment did not have Android SDK or Gradle installed, so no APK has been compiled or device-tested here.

## Remaining engineering milestones

1. Add authenticated Android-to-backend WebSocket client and device enrollment.
2. Replace demo code flow with cryptographically bound, one-time pairing and revocable credentials.
3. Add WebRTC screen streaming using MediaProjection, foreground service, ICE/STUN and a properly secured TURN server.
4. Add visible, session-scoped interaction controls; dispatch only permitted gestures through an explicitly enabled Accessibility service. Do not claim unrestricted control over protected/system surfaces.
5. Persist paired devices securely (Android Keystore + backend database), add audit log, revoke/logout, and session limits for 2–5 devices.
6. Test on real Android versions and OEMs, conduct security review, and only then produce signed release APKs.

## Security boundaries

- Pairing codes are temporary and single-use, not permanent passwords.
- The target must explicitly approve first-time pairing.
- The target owner can stop sessions and revoke access.
- A persistent foreground notification must make active remote access visible.
- Use TLS/WSS for signaling and WebRTC DTLS-SRTP for media.
- Do not hide the service, bypass Android permission dialogs, or capture protected content.

## Device-specific test plan

See [`DEVICE-TEST-PLAN-ID.md`](DEVICE-TEST-PLAN-ID.md) for the configured Infinix Hot 50 controller and Samsung Galaxy A15 4G host test plan. Record the exact Android/XOS/One UI and security patch versions from both phones before claiming compatibility; model names alone do not determine the installed OS version.
