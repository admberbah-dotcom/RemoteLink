package com.remotelink.app

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.security.SecureRandom

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var pairingCode: String? = null
    private val projectionRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            setBackgroundColor(0xFFF4F7FB.toInt())
        }
        val title = TextView(this).apply {
            text = "RemoteLink"
            textSize = 30f
            setTextColor(0xFF10213A.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        root.addView(text("Remote control Android • MVP 0.1.0", 14f, 0xFF53657D.toInt()))
        root.addView(space(24))
        root.addView(text("Pilih peran perangkat", 19f, 0xFF10213A.toInt(), true))
        root.addView(space(12))
        root.addView(actionButton("Jadikan HP ini sebagai PENGENDALI") { showController() })
        root.addView(space(10))
        root.addView(actionButton("Jadikan HP ini sebagai TARGET") { showHost() })
        root.addView(space(24))
        root.addView(text("Keamanan", 18f, 0xFF10213A.toInt(), true))
        root.addView(text("Perangkat target harus dipasangkan oleh pemiliknya. Android tetap menampilkan dialog izin sistem untuk berbagi layar. Akses dapat dihentikan dari perangkat target.", 14f, 0xFF53657D.toInt()))
        root.addView(space(18))
        root.addView(text("Status: prototipe antarmuka. Koneksi internet, server pairing, dan streaming WebRTC belum diaktifkan.", 13f, 0xFF9A4B16.toInt()))
        setContentView(root)
    }

    private fun showController() {
        baseScreen("Pengendali")
        root.addView(text("Masukkan kode pairing dari HP target", 16f, 0xFF10213A.toInt(), true))
        val input = android.widget.EditText(this).apply {
            hint = "Contoh: 123 456"
            textSize = 20f
            setSingleLine(true)
        }
        root.addView(input)
        root.addView(space(12))
        root.addView(actionButton("Pasangkan perangkat") {
            val code = input.text.toString().filter { it.isDigit() }
            if (code.length != 6) Toast.makeText(this, "Masukkan kode 6 digit", Toast.LENGTH_SHORT).show()
            else Toast.makeText(this, "UI siap. Server pairing belum dikonfigurasi.", Toast.LENGTH_LONG).show()
        })
        root.addView(space(16))
        root.addView(text("Perangkat tersimpan akan tampil di sini setelah layanan pairing dan autentikasi server disiapkan.", 14f, 0xFF53657D.toInt()))
        root.addView(backButton())
    }

    private fun showHost() {
        baseScreen("Perangkat target")
        root.addView(text("Kode pairing perangkat ini", 16f, 0xFF10213A.toInt(), true))
        val code = pairingCode ?: (100000 + SecureRandom().nextInt(900000)).toString().also { pairingCode = it }
        root.addView(text(code.chunked(3).joinToString(" "), 34f, 0xFF2563EB.toInt(), true))
        root.addView(text("Kode ini hanya contoh lokal pada prototipe. Belum diverifikasi oleh server dan belum dapat dipakai untuk koneksi jarak jauh.", 13f, 0xFF9A4B16.toInt()))
        root.addView(space(18))
        root.addView(actionButton("Aktifkan izin berbagi layar") { requestScreenCapture() })
        root.addView(space(10))
        root.addView(actionButton("Buka pengaturan Accessibility") {
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(space(14))
        root.addView(text("Izin hanya diaktifkan oleh pemilik HP target. Accessibility tidak memberikan akses diam-diam; Android menampilkan pengaturan sistem.", 14f, 0xFF53657D.toInt()))
        root.addView(backButton())
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility in this MVP")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest) {
            val message = if (resultCode == RESULT_OK) "Izin berbagi layar diberikan untuk sesi ini. Streaming belum diimplementasikan." else "Izin berbagi layar tidak diberikan."
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }

    private fun baseScreen(heading: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
            setBackgroundColor(0xFFF4F7FB.toInt())
        }
        root.addView(text("RemoteLink", 28f, 0xFF10213A.toInt(), true))
        root.addView(text(heading, 18f, 0xFF53657D.toInt()))
        root.addView(space(28))
        setContentView(root)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 6, 0, 6)
    }

    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, height) }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    }

    private fun backButton() = actionButton("Kembali ke beranda") { showHome() }
}
