# RemoteLink Signaling Backend 0.2.0

Node.js 20+ / WebSocket signaling prototype.

## Start

```sh
npm install
npm test
npm start
```

`GET /health` returns a small health response. `WS /signal` speaks JSON messages:

1. Host: `{ "type":"host.create", "deviceId":"target-1" }`
2. Host receives `{ "type":"host.pair-code", "code":"...", "expiresInSeconds":180 }`
3. Controller: `{ "type":"controller.join", "deviceId":"controller-1", "code":"..." }`
4. Host receives `pair.request`; controller receives `pair.waiting-for-host-approval`.
5. Host must send `{ "type":"pair.approve" }` or `{ "type":"pair.reject" }`.
6. After approval, relay `rtc.offer`, `rtc.answer`, and `rtc.ice` messages with a `payload` property.
7. Either peer can send `{ "type":"session.stop" }`.

The current implementation keeps state in memory. Restarting the process loses all challenges and sessions. It allows one active controller per host session. Do not use it as-is for production or unattended remote administration.

The backend deliberately rejects touch/gesture messages; implement those only after the app has verified session identity, visible target-side consent state, and Android Accessibility availability.
