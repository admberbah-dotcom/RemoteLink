import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

test('signaling server declares bounded payloads and one-time pairing expiry', async () => {
  const src = await readFile(new URL('../src/server.js', import.meta.url), 'utf8');
  assert.match(src, /PAIR_TTL_MS\s*=\s*3\s*\*\s*60\s*\*\s*1000/);
  assert.match(src, /maxPayload:\s*MAX_PAYLOAD/);
  assert.match(src, /PAIR_CODE_INVALID_OR_EXPIRED/);
  assert.match(src, /approvalRequired:\s*true/);
});

test('signaling server requires host approval before relaying RTC messages', async () => {
  const src = await readFile(new URL('../src/server.js', import.meta.url), 'utf8');
  assert.match(src, /PAIR_NOT_APPROVED/);
  assert.match(src, /pair\.approve/);
  assert.match(src, /rtc\.offer.*rtc\.answer.*rtc\.ice/s);
});
