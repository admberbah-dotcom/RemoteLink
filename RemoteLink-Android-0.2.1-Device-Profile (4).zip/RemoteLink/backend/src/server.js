import http from 'node:http';
import { randomInt, randomUUID, timingSafeEqual } from 'node:crypto';
import { WebSocketServer, WebSocket } from 'ws';

const PORT = Number(process.env.PORT || 8080);
const PAIR_TTL_MS = 3 * 60 * 1000;
const MAX_PAYLOAD = 64 * 1024;
const sessions = new Map();
const challenges = new Map();
const ipWindows = new Map();

function send(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function constantTimeEqual(a, b) {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}
function allowRequest(ip) {
  const now = Date.now(); const entry = ipWindows.get(ip) || { start: now, count: 0 };
  if (now - entry.start > 60_000) { entry.start = now; entry.count = 0; }
  entry.count += 1; ipWindows.set(ip, entry);
  return entry.count <= 40;
}
function cleanExpired() {
  const now = Date.now();
  for (const [code, item] of challenges) if (item.expiresAt < now) challenges.delete(code);
  for (const [id, item] of sessions) if (item.expiresAt && item.expiresAt < now) sessions.delete(id);
}
setInterval(cleanExpired, 30_000).unref();

const server = http.createServer((req, res) => {
  if (req.url === '/health' && req.method === 'GET') {
    res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    return res.end(JSON.stringify({ ok: true, service: 'RemoteLink signaling', version: '0.2.0' }));
  }
  res.writeHead(404); res.end('Not found');
});
const wss = new WebSocketServer({ noServer: true, maxPayload: MAX_PAYLOAD });
server.on('upgrade', (req, socket, head) => {
  const ip = req.socket.remoteAddress || 'unknown';
  if (!allowRequest(ip)) { socket.write('HTTP/1.1 429 Too Many Requests\r\n\r\n'); return socket.destroy(); }
  if (req.url !== '/signal') { socket.write('HTTP/1.1 404 Not Found\r\n\r\n'); return socket.destroy(); }
  wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req));
});

wss.on('connection', ws => {
  ws.role = null; ws.sessionId = null; ws.deviceId = null;
  send(ws, { type: 'hello', protocol: 1 });
  ws.on('message', raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return send(ws, { type: 'error', code: 'BAD_JSON' }); }
    if (!msg || typeof msg.type !== 'string') return send(ws, { type: 'error', code: 'BAD_MESSAGE' });

    if (msg.type === 'host.create') {
      if (ws.role) return send(ws, { type: 'error', code: 'ALREADY_AUTHENTICATED' });
      const deviceId = String(msg.deviceId || '').slice(0, 80);
      if (!deviceId) return send(ws, { type: 'error', code: 'DEVICE_ID_REQUIRED' });
      let code; do { code = String(randomInt(100000, 1_000_000)); } while (challenges.has(code));
      const challenge = randomUUID();
      challenges.set(code, { challenge, host: ws, deviceId, expiresAt: Date.now() + PAIR_TTL_MS });
      ws.role = 'host-pending'; ws.deviceId = deviceId; ws.pairCode = code;
      return send(ws, { type: 'host.pair-code', code, expiresInSeconds: 180, challenge });
    }

    if (msg.type === 'controller.join') {
      if (ws.role) return send(ws, { type: 'error', code: 'ALREADY_AUTHENTICATED' });
      const code = String(msg.code || '').replace(/\D/g, '');
      const item = challenges.get(code);
      if (!item || item.expiresAt < Date.now() || item.host.readyState !== WebSocket.OPEN) {
        challenges.delete(code); return send(ws, { type: 'error', code: 'PAIR_CODE_INVALID_OR_EXPIRED' });
      }
      const sessionId = randomUUID();
      const hostSecret = randomUUID(); const controllerSecret = randomUUID();
      const session = { id: sessionId, host: item.host, controller: ws, hostSecret, controllerSecret, expiresAt: null };
      sessions.set(sessionId, session); challenges.delete(code);
      item.host.role = 'host'; item.host.sessionId = sessionId;
      ws.role = 'controller'; ws.sessionId = sessionId;
      send(item.host, { type: 'pair.request', sessionId, controllerDeviceId: String(msg.deviceId || 'controller').slice(0, 80), approvalRequired: true });
      return send(ws, { type: 'pair.waiting-for-host-approval', sessionId });
    }

    if (msg.type === 'pair.approve' || msg.type === 'pair.reject') {
      const session = sessions.get(ws.sessionId);
      if (!session || ws !== session.host || ws.role !== 'host') return send(ws, { type: 'error', code: 'NOT_HOST' });
      if (msg.type === 'pair.reject') {
        send(session.controller, { type: 'pair.rejected' }); sessions.delete(session.id);
        session.controller.close(4003, 'Pairing rejected'); return;
      }
      session.expiresAt = Date.now() + 12 * 60 * 60 * 1000;
      send(session.controller, { type: 'pair.approved', sessionId: session.id });
      return send(ws, { type: 'pair.approved', sessionId: session.id });
    }

    const session = sessions.get(ws.sessionId);
    if (!session || (ws !== session.host && ws !== session.controller)) return send(ws, { type: 'error', code: 'NOT_PAIRED' });
    if (session.expiresAt && session.expiresAt < Date.now()) { sessions.delete(session.id); return send(ws, { type: 'error', code: 'SESSION_EXPIRED' }); }
    if (!session.expiresAt && !['session.stop'].includes(msg.type)) return send(ws, { type: 'error', code: 'PAIR_NOT_APPROVED' });

    const peer = ws === session.host ? session.controller : session.host;
    if (msg.type === 'session.stop') {
      send(peer, { type: 'session.stopped', by: ws.role }); sessions.delete(session.id);
      ws.close(1000, 'Session stopped'); peer.close(1000, 'Peer stopped session'); return;
    }
    if (['rtc.offer', 'rtc.answer', 'rtc.ice'].includes(msg.type)) {
      send(peer, { type: msg.type, payload: msg.payload }); return;
    }
    // Remote gestures are deliberately not relayed by this signaling MVP.
    send(ws, { type: 'error', code: 'UNSUPPORTED_MESSAGE' });
  });
  ws.on('close', () => {
    if (ws.pairCode) challenges.delete(ws.pairCode);
    if (ws.sessionId) {
      const session = sessions.get(ws.sessionId);
      if (session) {
        const peer = ws === session.host ? session.controller : session.host;
        send(peer, { type: 'peer.disconnected' });
        sessions.delete(session.id);
      }
    }
  });
});

server.listen(PORT, '0.0.0.0', () => console.log(`RemoteLink signaling listening on :${PORT}`));
