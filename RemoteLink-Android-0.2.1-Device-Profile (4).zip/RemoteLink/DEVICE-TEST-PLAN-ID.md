# RemoteLink — Rencana uji perangkat (Indonesia)

## Perangkat yang ditetapkan

- **Controller:** Infinix Hot 50
- **Host/target:** Samsung Galaxy A15 4G
- **Skenario:** kedua perangkat berada pada jaringan internet yang berbeda; pemilik A15 4G memulai pairing dan menyetujui akses pertama kali.

## Informasi yang wajib dicatat sebelum pengujian

Nama model pemasaran tidak cukup untuk menetapkan kompatibilitas OS. Catat dari masing-masing ponsel:

1. Pengaturan → Tentang ponsel → versi Android.
2. Versi XOS (Infinix) atau One UI (Samsung).
3. Patch keamanan Android.
4. Ruang penyimpanan kosong dan status penghemat baterai.

Jangan menganggap kedua unit menjalankan versi Android yang sama. Update sistem dan kebijakan OEM dapat berbeda antarwilayah/unit.

## Matriks uji

| Kasus | Infinix Hot 50 (controller) | Samsung A15 4G (host) | Hasil |
|---|---|---|---|
| Instalasi debug APK | Instal dan buka | Instal dan buka | Belum diuji |
| Pairing pertama | Masukkan kode dari host | Tampilkan kode dan minta persetujuan pemilik | Belum diuji |
| Screen capture | Tidak diperlukan | Persetujuan MediaProjection Android | Belum diuji |
| Streaming video | Tampilkan stream peer | Jalankan foreground service yang terlihat | Belum diimplementasikan |
| Kendali sentuh | Kirim input pada sesi aktif | Accessibility opt-in; hanya aksi yang diizinkan | Belum diimplementasikan |
| Putus koneksi | Tombol stop | Notifikasi/tombol stop dan pencabutan akses | Belum diuji |
| Reconnect | Autentikasi perangkat terdaftar | Tetap tampilkan indikator dan minta izin sistem jika diwajibkan OS | Belum diimplementasikan |
| Jaringan berbeda | Uji Wi-Fi ↔ seluler | Uji Wi-Fi ↔ seluler dengan TURN | Belum diimplementasikan |

## Batasan Android yang harus dipertahankan

- Pairing ulang aplikasi dapat dihindari dengan kredensial perangkat yang aman, tetapi persetujuan MediaProjection dapat diperlukan lagi ketika memulai sesi capture baru.
- Accessibility Service harus diaktifkan sendiri oleh pemilik host di Settings. Jangan mengaktifkan diam-diam atau menyembunyikan indikator.
- Android membatasi aksi pada layar aman, dialog sistem, dan konten yang dilindungi.
- Host harus memiliki notifikasi foreground yang jelas saat berbagi layar/koneksi remote aktif.
- Pemilik host harus selalu dapat menghentikan sesi dan mencabut perangkat yang pernah dipasangkan.

## Langkah uji manual setelah build tersedia

1. Instal APK yang sama pada kedua ponsel.
2. Pilih **Host** pada Samsung A15 4G dan **Controller** pada Infinix Hot 50.
3. Buat pairing baru; cocokkan kode dan setujui dari Samsung.
4. Berikan izin screen capture melalui dialog Android yang tampil.
5. Pastikan stream hanya terlihat setelah pairing disetujui.
6. Uji kontrol yang diizinkan pada aplikasi non-sensitif (misalnya layar beranda atau aplikasi demo).
7. Hentikan sesi dari kedua sisi dan pastikan stream serta kontrol berhenti.
8. Cabut perangkat terdaftar lalu pastikan kredensial lama tidak dapat menyambung.
9. Uji jaringan berbeda dan kondisi aplikasi di latar belakang; dokumentasikan konsumsi baterai dan kestabilan.

**Status:** rencana pengujian saja. Proyek saat ini belum memiliki WebRTC, TURN, koneksi Android ke signaling backend, atau implementasi input remote; tidak ada APK fungsional yang dihasilkan.
