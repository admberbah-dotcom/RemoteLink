package com.remotelink.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Explicitly opt-in accessibility endpoint.
 * Remote gesture commands are intentionally NOT accepted in this MVP. They must only
 * be added after authenticated pairing, consent checks, and a visible active-session UI.
 */
class RemoteAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit
}
